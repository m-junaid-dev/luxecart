export { default } from "../Footer";
