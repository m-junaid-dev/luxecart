export { default } from "../Hero";
